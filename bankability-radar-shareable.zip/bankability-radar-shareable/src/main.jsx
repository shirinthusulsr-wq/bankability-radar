import React from 'react';
import { createRoot } from 'react-dom/client';
import BankabilityRadar from './BankabilityRadar.jsx';

createRoot(document.getElementById('root')).render(<BankabilityRadar />);
