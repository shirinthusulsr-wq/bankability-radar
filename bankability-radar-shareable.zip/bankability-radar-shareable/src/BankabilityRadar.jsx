import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ResponsiveContainer, Legend, Tooltip as RTooltip
} from "recharts";
import {
  Plane, Plus, Trash2, AlertTriangle, CheckCircle2, TrendingUp,
  TrendingDown, Minus, Settings2, X
} from "lucide-react";

const CRITERIA = [
  { id: "narrative", label: "Project Narrative", short: "Narrative", desc: "Clarity and credibility of the investment story and why it is attractive to investors." },
  { id: "technology", label: "Technology Readiness", short: "Tech", desc: "Reliability and commercial viability of the proposed technology and production pathway." },
  { id: "construction", label: "Construction Risk", short: "Construction", desc: "Extent to which construction scope, cost, timeline and delivery risks are defined and allocated." },
  { id: "delivery", label: "Delivery Capability", short: "Delivery", desc: "Capability of the sponsor team and delivery structure to execute and operate the project." },
  { id: "feedstock", label: "Feedstock Security", short: "Feedstock", desc: "Availability, sustainability and price stability of inputs required for consistent production." },
  { id: "infrastructure", label: "Infrastructure & Permits", short: "Permits", desc: "Readiness of site, consents and enabling infrastructure required to build and operate the project." },
  { id: "capital", label: "Capital Structure", short: "Capital", desc: "Credibility of the financing approach and likelihood of securing debt and equity on acceptable terms." },
  { id: "revenue", label: "Contracted Revenue", short: "Revenue", desc: "Extent to which long-term, bankable revenue streams are in place to underpin project cashflows." },
  { id: "counterparties", label: "Creditworthy Counterparties", short: "Counterparties", desc: "Strength and reliability of contractual counterparties to meet long-term financial obligations." },
  { id: "policy", label: "Policy Support", short: "Policy", desc: "Clarity and durability of policy mechanisms that create and sustain demand for SAF." },
];

const uid = () => Math.random().toString(36).slice(2, 10);

function defaultValues(preset) {
  const base = {};
  CRITERIA.forEach((c) => { base[c.id] = (preset && preset[c.id] !== undefined) ? preset[c.id] : 3; });
  return base;
}

function defaultWeights() {
  const w = {};
  CRITERIA.forEach((c) => { w[c.id] = 1; });
  return w;
}

function seedProjects() {
  const initialValues = { narrative: 3, technology: 4, construction: 3, delivery: 2, feedstock: 3, infrastructure: 4, capital: 3, revenue: 2, counterparties: 3, policy: 2 };
  const laterValues = { ...initialValues, revenue: 4, feedstock: 4, policy: 4 };
  return [
    {
      id: uid(),
      name: "BlueSkyFuel (BSF)",
      snapshots: [
        { id: uid(), label: "Initial Assessment", date: "2026-01", values: initialValues, weights: defaultWeights() },
        { id: uid(), label: "6 Months Later", date: "2026-07", values: laterValues, weights: defaultWeights() },
      ],
    },
  ];
}

function bandFor(score) {
  if (score >= 80) return { label: "Bankable", color: "#3DD68C" };
  if (score >= 65) return { label: "Near Bankable", color: "#9AD657" };
  if (score >= 50) return { label: "In Development", color: "#F2A93B" };
  return { label: "Early Stage", color: "#E5484D" };
}

function scoreOf(values, weights) {
  let num = 0, den = 0;
  CRITERIA.forEach((c) => {
    const w = (weights && weights[c.id]) || 1;
    num += (values[c.id] || 0) * w;
    den += w;
  });
  if (den === 0) return 0;
  return Math.round((num / den) * 20);
}

export default function BankabilityRadar() {
  const [projects, setProjects] = useState(null);
  const [activeProjectId, setActiveProjectId] = useState(null);
  const [activeSnapId, setActiveSnapId] = useState(null);
  const [compareSnapId, setCompareSnapId] = useState(null);
  const [customWeights, setCustomWeights] = useState(false);
  const [saveState, setSaveState] = useState("idle");

  useEffect(() => {
    (async () => {
      try {
        const raw = window.localStorage.getItem("bankability:projects");
        const loaded = raw ? JSON.parse(raw) : null;
        const data = (loaded && loaded.length) ? loaded : seedProjects();
        setProjects(data);
        setActiveProjectId(data[0].id);
        setActiveSnapId(data[0].snapshots[data[0].snapshots.length - 1].id);
        setCompareSnapId(data[0].snapshots.length > 1 ? data[0].snapshots[data[0].snapshots.length - 2].id : null);
      } catch (e) {
        const data = seedProjects();
        setProjects(data);
        setActiveProjectId(data[0].id);
        setActiveSnapId(data[0].snapshots[data[0].snapshots.length - 1].id);
        setCompareSnapId(data[0].snapshots[0].id);
      }
    })();
  }, []);

  useEffect(() => {
    if (!projects) return;
    (async () => {
      setSaveState("saving");
      try {
        window.localStorage.setItem("bankability:projects", JSON.stringify(projects));
        setSaveState("saved");
      } catch (e) {
        setSaveState("error");
      }
    })();
  }, [projects]);

  const activeProject = useMemo(() => projects && projects.find((p) => p.id === activeProjectId), [projects, activeProjectId]);
  const activeSnap = useMemo(() => activeProject && activeProject.snapshots.find((s) => s.id === activeSnapId), [activeProject, activeSnapId]);
  const compareSnap = useMemo(() => activeProject && activeProject.snapshots.find((s) => s.id === compareSnapId), [activeProject, compareSnapId]);

  const updateActiveSnap = useCallback((patchFn) => {
    setProjects((prev) => prev.map((p) => {
      if (p.id !== activeProjectId) return p;
      return { ...p, snapshots: p.snapshots.map((s) => (s.id === activeSnapId ? patchFn(s) : s)) };
    }));
  }, [activeProjectId, activeSnapId]);

  const setValue = (critId, val) => updateActiveSnap((s) => ({ ...s, values: { ...s.values, [critId]: val } }));
  const setWeight = (critId, val) => updateActiveSnap((s) => ({ ...s, weights: { ...(s.weights || defaultWeights()), [critId]: val } }));

  const addProject = () => {
    const np = { id: uid(), name: "New Project", snapshots: [{ id: uid(), label: "Baseline", date: new Date().toISOString().slice(0, 7), values: defaultValues(), weights: defaultWeights() }] };
    setProjects((prev) => [...(prev || []), np]);
    setActiveProjectId(np.id);
    setActiveSnapId(np.snapshots[0].id);
    setCompareSnapId(null);
  };

  const deleteProject = (id) => {
    setProjects((prev) => {
      const rest = prev.filter((p) => p.id !== id);
      if (rest.length && activeProjectId === id) {
        setActiveProjectId(rest[0].id);
        setActiveSnapId(rest[0].snapshots[rest[0].snapshots.length - 1].id);
        setCompareSnapId(rest[0].snapshots.length > 1 ? rest[0].snapshots[rest[0].snapshots.length - 2].id : null);
      }
      return rest;
    });
  };

  const renameProject = (id, name) => setProjects((prev) => prev.map((p) => (p.id === id ? { ...p, name } : p)));

  const addSnapshot = () => {
    if (!activeProject) return;
    const lastVals = activeSnap ? activeSnap.values : defaultValues();
    const lastW = activeSnap ? activeSnap.weights : defaultWeights();
    const ns = { id: uid(), label: `Snapshot ${activeProject.snapshots.length + 1}`, date: new Date().toISOString().slice(0, 7), values: { ...lastVals }, weights: { ...lastW } };
    setProjects((prev) => prev.map((p) => (p.id === activeProjectId ? { ...p, snapshots: [...p.snapshots, ns] } : p)));
    setCompareSnapId(activeSnapId);
    setActiveSnapId(ns.id);
  };

  const deleteSnapshot = (id) => {
    setProjects((prev) => prev.map((p) => {
      if (p.id !== activeProjectId) return p;
      const remaining = p.snapshots.filter((s) => s.id !== id);
      return { ...p, snapshots: remaining.length ? remaining : [{ id: uid(), label: "Baseline", date: new Date().toISOString().slice(0, 7), values: defaultValues(), weights: defaultWeights() }] };
    }));
    if (id === activeSnapId && activeProject) {
      const remaining = activeProject.snapshots.filter((s) => s.id !== id);
      if (remaining.length) setActiveSnapId(remaining[remaining.length - 1].id);
    }
    if (id === compareSnapId) setCompareSnapId(null);
  };

  const renameSnapshot = (id, label) => {
    setProjects((prev) => prev.map((p) => (p.id === activeProjectId ? { ...p, snapshots: p.snapshots.map((s) => (s.id === id ? { ...s, label } : s)) } : p)));
  };

  if (!projects || !activeProject || !activeSnap) {
    return (
      <div style={wrapStyle}>
        <StyleBlock />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 400, color: "#7C8AA5", fontFamily: "IBM Plex Mono, monospace", fontSize: 13 }}>
          Loading bankability data…
        </div>
      </div>
    );
  }

  const score = scoreOf(activeSnap.values, customWeights ? activeSnap.weights : null);
  const band = bandFor(score);
  const compareScore = compareSnap ? scoreOf(compareSnap.values, customWeights ? compareSnap.weights : null) : null;

  const radarData = CRITERIA.map((c) => ({
    label: c.short,
    current: activeSnap.values[c.id],
    compare: compareSnap ? compareSnap.values[c.id] : undefined,
  }));

  const ranked = CRITERIA.map((c) => ({
    ...c,
    value: activeSnap.values[c.id],
    delta: compareSnap ? activeSnap.values[c.id] - compareSnap.values[c.id] : null,
  })).sort((a, b) => a.value - b.value);

  const weakest = ranked.slice(0, 3);
  const movedMost = compareSnap ? [...ranked].sort((a, b) => Math.abs(b.delta || 0) - Math.abs(a.delta || 0)).slice(0, 5) : [];
  const shownList = compareSnap ? movedMost : weakest;

  return (
    <div style={wrapStyle}>
      <StyleBlock />
      <header className="bk-header">
        <div className="bk-eyebrow">SPREAD · PROJECT FINANCE</div>
        <h1 className="bk-title">Bankability Radar</h1>
        <p className="bk-sub">
          Score a project against the ICAO Finvest Hub's ten bankability criteria, track how it moves over time,
          and see which lever would move it furthest toward investor-ready.
        </p>
      </header>

      <div className="bk-grid">
        <div className="bk-panel bk-left">
          <div className="bk-section-label">Project</div>
          <div className="bk-project-row">
            <input className="bk-input" value={activeProject.name} onChange={(e) => renameProject(activeProject.id, e.target.value)} />
            {projects.length > 1 && (
              <button className="bk-icon-btn" onClick={() => deleteProject(activeProject.id)} title="Delete project"><Trash2 size={14} /></button>
            )}
          </div>
          <div className="bk-chip-row">
            {projects.map((p) => (
              <button
                key={p.id}
                className={`bk-chip ${p.id === activeProjectId ? "active" : ""}`}
                onClick={() => {
                  setActiveProjectId(p.id);
                  setActiveSnapId(p.snapshots[p.snapshots.length - 1].id);
                  setCompareSnapId(p.snapshots.length > 1 ? p.snapshots[p.snapshots.length - 2].id : null);
                }}
              >
                {p.name}
              </button>
            ))}
            <button className="bk-chip add" onClick={addProject}><Plus size={12} /> New</button>
          </div>

          <div className="bk-section-label" style={{ marginTop: 18 }}>Snapshot</div>
          <div className="bk-snap-list">
            {activeProject.snapshots.map((s) => (
              <div key={s.id} className={`bk-snap-row ${s.id === activeSnapId ? "active" : ""}`}>
                <button className="bk-snap-select" onClick={() => setActiveSnapId(s.id)}>
                  <span className="bk-snap-dot" />
                  <input className="bk-snap-input" value={s.label} onClick={(e) => e.stopPropagation()} onChange={(e) => renameSnapshot(s.id, e.target.value)} />
                </button>
                <button className={`bk-compare-toggle ${compareSnapId === s.id ? "on" : ""}`} onClick={() => setCompareSnapId(compareSnapId === s.id ? null : s.id)} title="Compare against this snapshot">vs</button>
                {activeProject.snapshots.length > 1 && (
                  <button className="bk-icon-btn ghost" onClick={() => deleteSnapshot(s.id)} title="Delete snapshot"><X size={12} /></button>
                )}
              </div>
            ))}
          </div>
          <button className="bk-add-snap" onClick={addSnapshot}><Plus size={13} /> Add snapshot</button>

          <div className="bk-section-label bk-weight-header" style={{ marginTop: 22 }}>
            <span>Criteria</span>
            <label className="bk-weight-toggle">
              <input type="checkbox" checked={customWeights} onChange={(e) => setCustomWeights(e.target.checked)} />
              <Settings2 size={12} /> weight
            </label>
          </div>

          <div className="bk-criteria-list">
            {CRITERIA.map((c) => {
              const v = activeSnap.values[c.id];
              const w = (activeSnap.weights && activeSnap.weights[c.id]) || 1;
              const flagColor = v >= 4 ? "#3DD68C" : v === 3 ? "#F2A93B" : "#E5484D";
              return (
                <div className="bk-criterion" key={c.id}>
                  <div className="bk-criterion-head">
                    <span className="bk-flag" style={{ background: flagColor }} />
                    <span className="bk-criterion-label" title={c.desc}>{c.label}</span>
                    <span className="bk-criterion-value" style={{ color: flagColor }}>{v}</span>
                  </div>
                  <input type="range" min="1" max="5" step="1" value={v} onChange={(e) => setValue(c.id, Number(e.target.value))} className="bk-slider" style={{ accentColor: flagColor }} />
                  {customWeights && (
                    <div className="bk-weight-row">
                      <span>weight</span>
                      <input type="range" min="0.5" max="2" step="0.5" value={w} onChange={(e) => setWeight(c.id, Number(e.target.value))} className="bk-slider thin" />
                      <span className="bk-weight-val">{w}×</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="bk-right">
          <div className="bk-panel bk-runway-panel">
            <RunwayGauge score={score} compareScore={compareScore} band={band} label={activeSnap.label} compareLabel={compareSnap ? compareSnap.label : null} />
          </div>

          <div className="bk-panel bk-radar-panel">
            <div className="bk-panel-title">
              Criteria profile{compareSnap ? ` — ${activeSnap.label} vs ${compareSnap.label}` : ""}
            </div>
            <ResponsiveContainer width="100%" height={340}>
              <RadarChart data={radarData} outerRadius="72%">
                <PolarGrid stroke="#24314A" />
                <PolarAngleAxis dataKey="label" tick={{ fill: "#7C8AA5", fontSize: 11, fontFamily: "Inter, sans-serif" }} />
                <PolarRadiusAxis angle={30} domain={[0, 5]} tickCount={6} tick={{ fill: "#4C5A75", fontSize: 9 }} axisLine={false} />
                {compareSnap && (
                  <Radar name={compareSnap.label} dataKey="compare" stroke="#7C8AA5" fill="#7C8AA5" fillOpacity={0.1} strokeDasharray="4 3" strokeWidth={1.5} />
                )}
                <Radar name={activeSnap.label} dataKey="current" stroke="#F2A93B" fill="#F2A93B" fillOpacity={0.32} strokeWidth={2} />
                <Legend wrapperStyle={{ color: "#E8EDF5", fontSize: 12, fontFamily: "Inter, sans-serif" }} />
                <RTooltip contentStyle={{ background: "#121B2E", border: "1px solid #24314A", borderRadius: 8, fontFamily: "Inter, sans-serif", fontSize: 12 }} labelStyle={{ color: "#E8EDF5" }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="bk-panel bk-weak-panel">
            <div className="bk-panel-title">{compareSnap ? "What moved the score" : "Weakest links — where to focus next"}</div>
            <div className="bk-weak-list">
              {shownList.map((c) => (
                <div className="bk-weak-row" key={c.id}>
                  <div className="bk-weak-icon">
                    {c.value <= 2 ? <AlertTriangle size={15} color="#E5484D" /> : c.value === 3 ? <Minus size={15} color="#F2A93B" /> : <CheckCircle2 size={15} color="#3DD68C" />}
                  </div>
                  <div className="bk-weak-text">
                    <div className="bk-weak-label">{c.label}</div>
                    <div className="bk-weak-desc">{c.desc}</div>
                  </div>
                  <div className="bk-weak-score">
                    {compareSnap && c.delta !== null && c.delta !== 0 && (
                      <span className={`bk-delta ${c.delta > 0 ? "up" : "down"}`}>
                        {c.delta > 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />} {c.delta > 0 ? "+" : ""}{c.delta}
                      </span>
                    )}
                    <span className="bk-weak-num">{c.value}/5</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <footer className="bk-footer">
        Framework adapted from ICAO Finvest Hub's project bankability checklist. Scoring here is illustrative and self-assessed — not a substitute for investor due diligence.
        {saveState === "error" ? " · storage unavailable, changes won't persist" : ""}
      </footer>
    </div>
  );
}

function RunwayGauge({ score, compareScore, band, label, compareLabel }) {
  const W = 1000, H = 150;
  const padX = 50;
  const trackW = W - padX * 2;
  const zones = [
    { from: 0, to: 50, color: "#E5484D22", line: "#E5484D" },
    { from: 50, to: 65, color: "#F2A93B22", line: "#F2A93B" },
    { from: 65, to: 80, color: "#9AD65722", line: "#9AD657" },
    { from: 80, to: 100, color: "#3DD68C22", line: "#3DD68C" },
  ];
  const xFor = (s) => padX + (Math.max(0, Math.min(100, s)) / 100) * trackW;
  const leftPct = (s) => `${5 + (Math.max(0, Math.min(100, s)) / 100) * 90}%`;

  return (
    <div className="bk-runway-wrap">
      <div className="bk-score-readout">
        <span className="bk-score-num" style={{ color: band.color }}>{score}</span>
        <span className="bk-score-den">/100</span>
        <span className="bk-score-band" style={{ color: band.color, borderColor: band.color }}>{band.label}</span>
      </div>

      <div className="bk-runway-svgwrap">
        <svg viewBox={`0 0 ${W} ${H}`} className="bk-runway-svg" preserveAspectRatio="none">
          {zones.map((z, i) => (
            <rect key={i} x={xFor(z.from)} y={60} width={xFor(z.to) - xFor(z.from)} height={40} fill={z.color} stroke={z.line} strokeOpacity={0.4} />
          ))}
          <line x1={padX} y1={80} x2={W - padX} y2={80} stroke="#3A4A6B" strokeWidth={2} strokeDasharray="16 14" />
          {[0, 50, 65, 80, 100].map((v) => (
            <g key={v}>
              <line x1={xFor(v)} y1={50} x2={xFor(v)} y2={115} stroke="#3A4A6B" strokeWidth={1} />
              <text x={xFor(v)} y={132} textAnchor="middle" fontSize="13" fill="#7C8AA5" fontFamily="IBM Plex Mono, monospace">{v}</text>
            </g>
          ))}
        </svg>

        {compareScore != null && (
          <div className="bk-plane-compare" style={{ left: leftPct(compareScore) }}>
            <Plane size={15} color="#7C8AA5" style={{ transform: "rotate(90deg)", opacity: 0.7 }} />
          </div>
        )}
        <div className="bk-plane-current" style={{ left: leftPct(score) }}>
          <Plane size={20} color={band.color} style={{ transform: "rotate(90deg)" }} />
        </div>
      </div>

      <div className="bk-runway-labels">
        <span>Early Stage</span><span>In Development</span><span>Near Bankable</span><span>Bankable</span>
      </div>

      {(label || compareLabel) && (
        <div className="bk-runway-legend">
          <span><i style={{ background: band.color }} /> {label} ({score})</span>
          {compareLabel && <span className="ghost"><i style={{ background: "#7C8AA5" }} /> {compareLabel} ({compareScore})</span>}
        </div>
      )}
    </div>
  );
}

function StyleBlock() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@500;600&display=swap');

      .bk-header { margin-bottom: 22px; }
      .bk-eyebrow { font-family: 'IBM Plex Mono', monospace; font-size: 11px; letter-spacing: 0.14em; color: #F2A93B; text-transform: uppercase; }
      .bk-title { font-family: 'Space Grotesk', sans-serif; font-size: 30px; margin: 5px 0 8px; font-weight: 700; color: #E8EDF5; }
      .bk-sub { color: #7C8AA5; font-size: 13.5px; max-width: 680px; line-height: 1.55; margin: 0; }

      .bk-grid { display: grid; grid-template-columns: 300px 1fr; gap: 18px; }
      @media (max-width: 860px) { .bk-grid { grid-template-columns: 1fr; } }

      .bk-panel { background: #121B2E; border: 1px solid #24314A; border-radius: 14px; padding: 18px; }
      .bk-left { max-height: 920px; overflow-y: auto; }
      .bk-left::-webkit-scrollbar, .bk-criteria-list::-webkit-scrollbar { width: 6px; }
      .bk-left::-webkit-scrollbar-thumb, .bk-criteria-list::-webkit-scrollbar-thumb { background: #24314A; border-radius: 3px; }

      .bk-section-label { font-family: 'IBM Plex Mono', monospace; font-size: 10.5px; letter-spacing: 0.1em; text-transform: uppercase; color: #7C8AA5; }
      .bk-weight-header { display: flex; align-items: center; justify-content: space-between; }
      .bk-weight-toggle { display: flex; align-items: center; gap: 4px; font-size: 11px; color: #7C8AA5; cursor: pointer; font-family: 'IBM Plex Mono', monospace; text-transform: none; letter-spacing: 0; }

      .bk-project-row { display: flex; gap: 6px; align-items: center; margin-top: 6px; }
      .bk-input { background: #16213A; border: 1px solid #24314A; color: #E8EDF5; padding: 8px 10px; border-radius: 8px; font-family: 'Space Grotesk', sans-serif; font-size: 15px; flex: 1; min-width: 0; }
      .bk-input:focus { outline: none; border-color: #F2A93B; }

      .bk-chip-row { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
      .bk-chip { background: #16213A; border: 1px solid #24314A; color: #7C8AA5; padding: 5px 10px; border-radius: 20px; font-size: 12px; cursor: pointer; font-family: Inter, sans-serif; }
      .bk-chip.active { border-color: #F2A93B; color: #E8EDF5; }
      .bk-chip.add { display: flex; align-items: center; gap: 4px; border-style: dashed; }

      .bk-snap-list { display: flex; flex-direction: column; gap: 2px; margin-top: 8px; }
      .bk-snap-row { display: flex; align-items: center; gap: 6px; padding: 6px 8px; border-radius: 8px; }
      .bk-snap-row.active { background: #16213A; }
      .bk-snap-select { flex: 1; display: flex; align-items: center; gap: 8px; background: none; border: none; color: #E8EDF5; cursor: pointer; text-align: left; padding: 0; min-width: 0; }
      .bk-snap-dot { width: 7px; height: 7px; border-radius: 50%; background: #7C8AA5; flex-shrink: 0; }
      .bk-snap-row.active .bk-snap-dot { background: #F2A93B; }
      .bk-snap-input { background: none; border: none; color: inherit; font-family: Inter, sans-serif; font-size: 13px; width: 100%; padding: 2px 0; min-width: 0; }
      .bk-snap-input:focus { outline: none; border-bottom: 1px solid #24314A; }
      .bk-compare-toggle { font-family: 'IBM Plex Mono', monospace; font-size: 10px; padding: 3px 6px; border-radius: 5px; border: 1px solid #24314A; background: none; color: #7C8AA5; cursor: pointer; }
      .bk-compare-toggle.on { background: #7C8AA5; color: #0B1220; border-color: #7C8AA5; }
      .bk-icon-btn { background: none; border: none; color: #7C8AA5; cursor: pointer; padding: 4px; border-radius: 6px; display: flex; }
      .bk-icon-btn:hover { background: #16213A; color: #E5484D; }
      .bk-icon-btn.ghost { opacity: 0.55; }

      .bk-add-snap { margin-top: 8px; display: flex; align-items: center; gap: 6px; background: none; border: 1px dashed #24314A; color: #7C8AA5; font-size: 12px; padding: 7px 10px; border-radius: 8px; cursor: pointer; width: 100%; justify-content: center; font-family: Inter, sans-serif; }
      .bk-add-snap:hover { color: #E8EDF5; border-color: #F2A93B; }

      .bk-criteria-list { display: flex; flex-direction: column; gap: 14px; margin-top: 10px; max-height: 480px; overflow-y: auto; padding-right: 4px; }
      .bk-criterion-head { display: flex; align-items: center; gap: 8px; margin-bottom: 5px; }
      .bk-flag { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
      .bk-criterion-label { font-size: 12.5px; flex: 1; cursor: help; color: #E8EDF5; }
      .bk-criterion-value { font-family: 'IBM Plex Mono', monospace; font-size: 13px; font-weight: 600; }
      .bk-slider { width: 100%; height: 4px; cursor: pointer; }
      .bk-slider.thin { height: 3px; }
      .bk-weight-row { display: flex; align-items: center; gap: 8px; margin-top: 5px; font-size: 10px; color: #7C8AA5; }
      .bk-weight-val { font-family: 'IBM Plex Mono', monospace; width: 24px; }

      .bk-right { display: flex; flex-direction: column; gap: 18px; }
      .bk-panel-title { font-family: 'Space Grotesk', sans-serif; font-size: 14px; margin-bottom: 12px; color: #E8EDF5; font-weight: 600; }

      .bk-runway-wrap { display: flex; flex-direction: column; align-items: center; gap: 2px; }
      .bk-score-readout { display: flex; align-items: baseline; gap: 6px; margin-bottom: 10px; }
      .bk-score-num { font-family: 'IBM Plex Mono', monospace; font-size: 46px; font-weight: 600; line-height: 1; }
      .bk-score-den { font-family: 'IBM Plex Mono', monospace; font-size: 16px; color: #7C8AA5; }
      .bk-score-band { margin-left: 10px; font-family: 'IBM Plex Mono', monospace; font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; border: 1px solid; padding: 3px 10px; border-radius: 20px; }
      .bk-runway-svgwrap { position: relative; width: 100%; max-width: 720px; aspect-ratio: 1000 / 150; }
      .bk-runway-svg { width: 100%; height: 100%; }
      .bk-plane-current, .bk-plane-compare { position: absolute; transform: translateX(-50%); transition: left 0.5s cubic-bezier(.4,0,.2,1); filter: drop-shadow(0 2px 4px rgba(0,0,0,0.5)); }
      .bk-plane-current { top: 6%; }
      .bk-plane-compare { top: 16%; }
      .bk-runway-labels { display: flex; justify-content: space-between; width: 100%; max-width: 720px; font-family: 'IBM Plex Mono', monospace; font-size: 10px; color: #7C8AA5; padding: 0 6px; margin-top: 2px; }
      .bk-runway-legend { display: flex; gap: 16px; margin-top: 10px; font-size: 11.5px; color: #7C8AA5; flex-wrap: wrap; justify-content: center; }
      .bk-runway-legend i { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 5px; }
      .bk-runway-legend .ghost { opacity: 0.75; }

      .bk-weak-list { display: flex; flex-direction: column; gap: 10px; }
      .bk-weak-row { display: flex; align-items: flex-start; gap: 10px; padding: 10px 12px; background: #16213A; border-radius: 10px; }
      .bk-weak-icon { margin-top: 2px; flex-shrink: 0; }
      .bk-weak-text { flex: 1; min-width: 0; }
      .bk-weak-label { font-size: 13px; font-weight: 600; color: #E8EDF5; }
      .bk-weak-desc { font-size: 11.5px; color: #7C8AA5; margin-top: 2px; line-height: 1.45; }
      .bk-weak-score { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
      .bk-weak-num { font-family: 'IBM Plex Mono', monospace; font-size: 12px; color: #7C8AA5; }
      .bk-delta { display: flex; align-items: center; gap: 3px; font-family: 'IBM Plex Mono', monospace; font-size: 11px; padding: 2px 6px; border-radius: 10px; }
      .bk-delta.up { color: #3DD68C; background: rgba(61,214,140,0.12); }
      .bk-delta.down { color: #E5484D; background: rgba(229,72,77,0.12); }

      .bk-footer { margin-top: 20px; font-size: 11px; color: #7C8AA5; text-align: center; line-height: 1.5; }

      @media (max-width: 520px) {
        .bk-title { font-size: 24px; }
        .bk-score-num { font-size: 36px; }
      }
    `}</style>
  );
}

const wrapStyle = {
  background: "#0B1220",
  color: "#E8EDF5",
  fontFamily: "Inter, sans-serif",
  padding: "26px 26px 20px",
  borderRadius: 16,
  minHeight: 600,
};
